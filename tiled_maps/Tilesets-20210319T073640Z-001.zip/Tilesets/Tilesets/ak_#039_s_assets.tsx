<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="ak&amp;#039;s_assets" tilewidth="32" tileheight="32" tilecount="504" columns="24">
 <image source="ak&amp;#039;s_assets.png" width="768" height="672"/>
</tileset>
