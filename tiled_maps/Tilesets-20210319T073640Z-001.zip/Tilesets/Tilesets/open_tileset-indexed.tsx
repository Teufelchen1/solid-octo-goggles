<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="open_tileset-indexed" tilewidth="32" tileheight="32" tilecount="1710" columns="45">
 <image source="open_tileset-indexed.png" width="1440" height="1216"/>
</tileset>
