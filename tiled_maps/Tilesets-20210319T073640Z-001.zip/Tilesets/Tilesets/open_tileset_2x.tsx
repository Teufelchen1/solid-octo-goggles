<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="open_tileset_2x" tilewidth="32" tileheight="32" tilecount="6840" columns="90">
 <image source="open_tileset_2x.png" width="2880" height="2432"/>
</tileset>
